CLI
===

This package implements the Sliver client cli.
