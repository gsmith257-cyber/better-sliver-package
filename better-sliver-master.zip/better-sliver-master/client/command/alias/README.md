Alias
===========

Wraps external DLLs/tool in Sliver console commands.



### Format

* `alias-dir/`
* * `manifest.json` - 
