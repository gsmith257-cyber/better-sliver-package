Backdoor
========

Implements command related to `backdoor`
