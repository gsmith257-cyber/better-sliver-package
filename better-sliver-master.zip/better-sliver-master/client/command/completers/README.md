Completers
===========

This package contains general purpose completers for the console, note that some package also contain their own package-specific completers. 
