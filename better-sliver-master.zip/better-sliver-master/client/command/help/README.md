Help
====

This package contains all of the long-form command help templates that are displayed when a user types `help <cmd>`
