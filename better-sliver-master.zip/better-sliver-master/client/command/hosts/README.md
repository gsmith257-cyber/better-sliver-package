Hosts
======

Command to access and manage host information.
