package licenses

import (
	"github.com/spf13/cobra"

	"github.com/gsmith257-cyber/better-sliver/client/command/help"
	"github.com/gsmith257-cyber/better-sliver/client/console"
	consts "github.com/gsmith257-cyber/better-sliver/client/constants"
	"github.com/gsmith257-cyber/better-sliver/client/licenses"
)

// Commands returns the `licences` command.
func Commands(con *console.SliverClient) []*cobra.Command {
	licensesCmd := &cobra.Command{
		Use:   consts.LicensesStr,
		Short: "Open source licenses",
		Long:  help.GetHelpFor([]string{consts.LicensesStr}),
		Run: func(cmd *cobra.Command, args []string) {
			con.Println(licenses.All)
		},
		GroupID: consts.GenericHelpGroup,
	}

	return []*cobra.Command{licensesCmd}
}
