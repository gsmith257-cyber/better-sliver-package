Pivots
=======

Pivot related command implementations, pivots are specifically for pivoting C2 traffic (not to be confused with port forwarding)

