Privilege
==========

Commands related to manipulation of operating system privileges, such as Windows Tokens.

