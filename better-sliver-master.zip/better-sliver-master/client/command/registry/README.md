Registry
========

Commands for manipulating the Windows registry.
