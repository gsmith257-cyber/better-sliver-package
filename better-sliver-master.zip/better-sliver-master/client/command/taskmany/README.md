Taskmany
========
This package implements the `taskmany` command, which is used to task multiple beacons or sessions at once
