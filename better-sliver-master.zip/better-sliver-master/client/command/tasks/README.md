Tasks
=======

Manage and interact with Beacon tasks

