Update
======

Implements the `update` command
