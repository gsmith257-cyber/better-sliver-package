Licenses
=========

Copies of OSS licenses to be included in binary distributions.

