The Sliver authors do not consider anti-virus evasion to be within the scope of the Sliver project; there is already a myriad of works in this area. That said, Sliver is designed to be interoperable with common techniques for bypassing anti-virus software such as packers, crypters, and [stagers](/docs?name=Stagers).

Here are some external resources for anti-virus evasion:

- https://www.veil-framework.com/framework/veil-evasion/
- https://iwantmore.pizza/posts/PEzor.html
