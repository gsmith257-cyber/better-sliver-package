import { NextPage } from "next";

const IndexPage: NextPage = () => {
  return (
    <div>
      <p>Coming soon...</p>
    </div>
  );
};

export default IndexPage;
